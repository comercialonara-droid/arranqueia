/**
 * Carrega a configuração da loja, o estoque e os vendedores a partir de um JSON.
 *   npm run seed                       → seed/fa-veiculos.json
 *   npm run seed -- outro-arquivo.json
 *   npm run seed -- --reset            → apaga o estoque antes
 *   npm run seed -- --fotos-demo       → cria fotos de exemplo (só para testar no simulador)
 */
import fs from "node:fs";
import path from "node:path";
import { config } from "../config.js";
import { db } from "../db/index.js";
import { sellers, vehicles } from "../db/repos.js";
import { saveSettings } from "../db/settings.js";

const args = process.argv.slice(2);
const file = path.resolve(args.find((a) => !a.startsWith("--")) ?? "seed/fa-veiculos.json");
const reset = args.includes("--reset");
const fotosDemo = args.includes("--fotos-demo");

const data = JSON.parse(fs.readFileSync(file, "utf8"));

if (data.config) saveSettings(data.config);

if (reset) db.exec("DELETE FROM vehicles");

const palettes = [
  ["#1d2630", "#f2c230"],
  ["#2a2320", "#e9e2d0"],
  ["#14202b", "#7fb2d9"],
];
const views = ["Frente", "Lateral 3/4", "Traseira", "Interior", "Painel"];

function demoPhoto(id: string, title: string, i: number) {
  const [bg, fg] = palettes[i % palettes.length];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="810" viewBox="0 0 1080 810">
  <rect width="1080" height="810" fill="${bg}"/>
  <g fill="none" stroke="${fg}" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" opacity=".9">
    <path d="M190 520 h700 M240 520 l60-120 q20-40 70-40 h330 q50 0 80 40 l90 120"/>
    <circle cx="340" cy="540" r="62"/><circle cx="750" cy="540" r="62"/>
  </g>
  <text x="540" y="680" fill="${fg}" font-family="Arial, sans-serif" font-size="44" text-anchor="middle">${title.replace(/&/g, "&amp;")}</text>
  <text x="540" y="740" fill="${fg}" opacity=".6" font-family="Arial, sans-serif" font-size="30" text-anchor="middle">${views[i]} · foto de exemplo</text>
</svg>`;
  const name = `demo-${id}-${i + 1}.svg`;
  fs.writeFileSync(path.join(config.dataDir, "uploads", name), svg);
  return { url: `/uploads/${name}`, legenda: views[i] };
}

let n = 0;
for (const v of data.veiculos ?? []) {
  const exists = vehicles.get(v.id);
  if (exists && !reset) continue;
  const fotos = v.fotos?.length ? v.fotos : fotosDemo ? [0, 1, 2, 3].map((i) => demoPhoto(v.id, `${v.marca} ${v.modelo} ${v.versao ?? ""}`.trim(), i)) : [];
  vehicles.upsert({ status: "disponivel", opcionais: [], destaques: [], ...v, fotos });
  n++;
}

if (!sellers.all().length) {
  for (const s of data.vendedores ?? []) {
    const created = sellers.create(s.nome, s.whatsapp ?? "");
    if (s.ativo === false) sellers.update(created.id, { ativo: false });
  }
}

console.log(`Pronto: ${n} veículos carregados de ${path.basename(file)}${fotosDemo ? " (com fotos de exemplo)" : ""}.`);
